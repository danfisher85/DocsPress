<?php

/**
 * @author: VLThemes
 * @version: 1.0.0
 */

if ( is_active_sidebar( 'blog_sidebar' ) ) {
	dynamic_sidebar( 'blog_sidebar' );
}