<?php

	get_template_part( 'template-parts/footer/footer' );
	do_action( 'docs/after_site' );

?>

<?php wp_footer(); ?>

</body>
</html>